#include "LoginUsuario.h"

void comproDatos(usuario* vUsuario, int n){
    printf("%i\n%i\n%s\n%s\n%s\n",vUsuario[n].id_usuario, vUsuario[n].Perfil_usuario, vUsuario[n].Contrasenna, vUsuario[n].Usuario , vUsuario[n].Nomb_usuario);

}

int main(){
    usuario* vUsuario = NULL;
    int nUsuario = 0;
    
    cargarUsuarios(&vUsuario, &nUsuario);
    //menuPrincipal(vUsuario, &nUsuario);
    gestionarUsuario(&vUsuario, &nUsuario);
    
    //printf("%i\n", nUsuario);
    //comproDatos(vUsuario, 0);
    descargarUsuarios(vUsuario, &nUsuario);

}

